<!DOCTYPE HTML>

<html lang = "pt-br">
    <head>
        <title>Atores em Destaque</title>
        <link rel="stylesheet" href="css/style_atores.css">
    </head>
    <body>
        <header>
            <!--CABECALHO LOGO-->
            <div id="header_logo">
                <div id="div_imagem_logo">
                    <a href="index.php" class="link">
                        <figure class="link">
                            <img src="imagens/logo.png" class="imagem_logo">
                        </figure>
                    </a>    
                </div>
            </div>
            
                <!--CABECALHO MENU-->
                   <nav id="header_menu">
                    <ul id="menu_lista">
                        <a href = "atores_em_destaque.php" class="link">
                            <li class="menu_lista_itens">atores </li>
                        </a>
                            <li class="menu_lista_itens"> locadora</li>
                            <li class="menu_lista_itens">promoções</li>
                            <li class="menu_lista_itens"> lojas</li>
                            <li class="menu_lista_itens">filmes </li>
                            <li class="menu_lista_itens">fale conosco</li>
                    </ul>
                </nav>

                <!--CABECALHO LOGIN-->
            <div id="header_login">
                <form method="post" action="">
                    <div id='header_login_caixas'>
                        <div class='login_caixas_input'>
                            Usuario: <br><input type="text" name="txt_usuario">
                        </div>
                        <div class='login_caixas_input'>
                            Senha:<br><input type="text" name="txt_senha">
                        </div>
                        <div id='login_caixas_botao'>
                            <input type="submit" name="btn_login">
                        </div>
                    </div>
                </form>    
            </div>           
        </header>
        
        
    <div id="centralizar">
        <div id="corpo">
            <div id="espaco"></div>
                <div id="corpo_menu">
                    <ul id="lista2">
                        <li class="item_lista2">Item</li>
                        <li class="item_lista2">Item</li>
                    </ul>
                </div>
                
                <section id="corpo_atores_destaque">
                  <h2 id="titulo_atores">Atores em Destaque</h2> 
                    
                    <ul id="lista_atores_destaque">
                        <li class="ator_destaque">  
                                <div class="imagem_ator_destaque">
                                    <figure class="link">
                                        <img src="imagens/ator1.jpeg" class="imagem_icone" alt="atriz de patrulha do destino">
                                    </figure>
                                </div>
                                <div class="info_ator_destaque">

                                </div>
                        </li>
                        <li class="ator_destaque">
                            <div class="imagem_ator_destaque">
                                <figure class="link">
                                    <img src="imagens/ator2.png" class="imagem_icone" alt="Ator de doom patrol">
                                </figure>
                            </div>
                            <div class="info_ator_destaque">
                            </div>
                        </li>
                        <li class="ator_destaque">  
                            <div class="imagem_ator_destaque">
                                <figure class="link">
                                    <img src="imagens/ator3.jpg" class="imagem_icone" alt="atores de doom patrol">
                                </figure>
                            </div>
                            <div class="info_ator_destaque">
                                
                            </div>
                        </li>
                        <li class="ator_destaque">  
                            <div class="imagem_ator_destaque">
                                <figure class="link">
                                    <img src="imagens/ator4.png" class="imagem_icone" alt="atores de doom patrol">
                                </figure>
                            </div>
                            <div class="info_ator_destaque">
                            </div>
                        </li>
                    </ul>
                
                </section>
            
            </div>
            
        <div id="redes_sociais">
            <a href="">
                <img src="imagens/facebook.png" class="imagens_redes_sociais" id="facebook" alt="Facebook">
            </a>
            
            <a href="">
                <img src="imagens/snap.png" class="imagens_redes_sociais" alt="Snapchat">
            </a>
            
            <a href="">
                <img src="imagens/intagram.png" class="imagens_redes_sociais" 
                alt="instagram">
            </a>
            
            <a href="">
                <img src="imagens/twitter.png" class="imagens_redes_sociais"
                alt="twitter">
            </a>
        </div>    
        </div>
        
        <footer id="rodape">
        </footer>
        
    </body>
</html>